"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import {
  Heart,
  Search,
  User,
  Menu,
  X,
} from "lucide-react";
import {
  SignInButton,
  SignUpButton,
  UserButton,
  useUser,
} from "@clerk/nextjs";
import { usePathname } from "next/navigation";
import { useWishlist } from "@/context/WishlistContext";
import CartBadge from "@/components/common/CartBadge";
import SearchOverlay from "@/components/search/SearchOverlay";
import { AnimatePresence, motion } from "framer-motion";

export default function Navbar() {
  const [searchOpen, setSearchOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const pathname = usePathname();
  const { wishlist } = useWishlist();
  const { isSignedIn } = useUser();
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [pathname]);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setMobileMenuOpen(false);
      }
    };

    window.addEventListener("keydown", handleKeyDown);

    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, []);

  const navigation = [
    {
      label: "Shop",
      href: "/shop",
    },
    {
      label: "Collections",
      href: "/collections",
    },
    {
      label: "Wholesale",
      href: "/wholesale",
    },
    {
      label: "About",
      href: "/about",
    },
    {
      label: "Contact",
      href: "/contact",
    },
  ];

  return (
    <>
      <header className="fixed left-0 top-0 z-50 w-full px-3 sm:px-4 md:px-8">
        <div className="mx-auto mt-4 flex h-12 max-w-7xl items-center justify-between rounded-full border border-neutral-200 bg-white/80 px-4 shadow-lg backdrop-blur-xl md:mt-6 md:h-14 md:px-8">
          {/* Logo */}
          <div className="flex items-center gap-3">
            {/* Mobile Menu */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              className="flex h-9 w-9 items-center justify-center rounded-full transition hover:bg-neutral-100 lg:hidden"
              aria-label="Open menu"
            >
              <Menu size={20} />
            </button>

            {/* Logo */}
            <Link href="/">
              <Image
                src="/images/logo-wordmark.png"
                alt="TIZA"
                width={115}
                height={35}
                className="h-auto w-[92px] md:w-[115px]"
                priority
              />
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden items-center gap-10 text-sm lg:flex">            <Link href="/shop" className="transition hover:text-neutral-500">
            Shop
          </Link>

            <Link
              href="/collections"
              className="transition hover:text-neutral-500"
            >
              Collections
            </Link>

            <Link
              href="/wholesale"
              className="transition hover:text-neutral-500"
            >
              Wholesale
            </Link>

            <Link href="/about" className="transition hover:text-neutral-500">
              About
            </Link>

            <Link
              href="/contact"
              className="transition hover:text-neutral-500"
            >
              Contact
            </Link>
          </nav>

          {/* Right Side */}
          <div className="flex items-center gap-2 md:gap-4">
            {/* Search */}
            <button
              type="button"
              onClick={() => setSearchOpen(true)}
              className="transition hover:text-neutral-500"
            >
              <Search size={18} />
            </button>

            {/* Wishlist */}
            <Link
              href="/wishlist"
              className="relative transition hover:text-neutral-500"
            >
              <Heart size={18} />

              {wishlist.length > 0 && (
                <span className="absolute -right-2 -top-2 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[9px] font-medium text-white">
                  {wishlist.length}
                </span>
              )}
            </Link>

            {/* Cart */}
            <CartBadge />

            {/* Authentication */}
            {isSignedIn ? (
              <UserButton
                appearance={{
                  elements: {
                    avatarBox: "h-9 w-9",
                  },
                }}
              />
            ) : (
              <>
                {/* Desktop */}
                <div className="hidden items-center gap-2 md:flex">
                  <SignInButton mode="modal">
                    <button className="rounded-full border border-neutral-300 px-4 py-2 text-sm transition hover:bg-neutral-100">
                      Sign In
                    </button>
                  </SignInButton>

                  <SignUpButton mode="modal">
                    <button className="rounded-full bg-black px-4 py-2 text-sm text-white transition hover:bg-neutral-800">
                      Sign Up
                    </button>
                  </SignUpButton>
                </div>

                {/* Mobile */}
                <div className="md:hidden">
                  <SignInButton mode="modal">
                    <button className="flex h-9 w-9 items-center justify-center rounded-full border border-neutral-300 transition hover:bg-neutral-100">
                      <User size={18} />
                    </button>
                  </SignInButton>
                </div>
              </>
            )}
          </div>
        </div>
      </header>

      <SearchOverlay
        open={searchOpen}
        onClose={() => setSearchOpen(false)}
      />
    </>
  );
}